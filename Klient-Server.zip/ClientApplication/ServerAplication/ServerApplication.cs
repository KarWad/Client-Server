﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using System.Threading;

namespace ServerApplication
{
    class ServerApplication
    {
        static void Main(string[] args)
        {
            //Uruchom metodę PrintIncomingMessage po odebraniu pakietu typu „Message”
            //Oczekujemy, że przychodzący obiekt będzie ciągiem, który określamy jawnie za pomocą <string>
            NetworkComms.AppendGlobalIncomingPacketHandler<string>("Wiadomość", PrintIncomingMessage);
            //Rozpocznij nasłuchiwanie połączeń przychodzących
            Connection.StartListening(ConnectionType.TCP, new System.Net.IPEndPoint(System.Net.IPAddress.Any, 0));


            //Wydrukuj adresy IP i porty, na których teraz nasłuchujemy
            Console.WriteLine("Serwer nasłuchuje połączenia TCP na:");
            foreach (System.Net.IPEndPoint localEndPoint in Connection.ExistingLocalListenEndPoints(ConnectionType.TCP))
                Console.WriteLine("{0}:{1}", localEndPoint.Address, localEndPoint.Port);

            //Pozwól użytkownikowi zamknąć serwer
            Console.WriteLine("\nNaciśnij dowolny klawisz, aby zamknąć serwer.");
            Console.ReadKey(true);

            //Użyliśmy NetworkComms, więc powinniśmy upewnić się, że poprawnie wywołaliśmy zamknięcie
            NetworkComms.Shutdown();
        }

        /// <podsumowanie>
        /// Zapisuje dostarczoną wiadomość w oknie konsoli
        /// </podsumowanie>
        /// <param name="header">Nagłówek pakietu powiązany z przychodzącą wiadomością</param>
        /// <param name="connection">Połączenie używane przez przychodzącą wiadomość</param>
        /// <param name="message">Wiadomość do wyświetlenia w konsoli</param>
        private static void PrintIncomingMessage(PacketHeader header, Connection connection, string message)
        {
            Console.WriteLine("\nOtrzymano wiadomość od " + connection.ToString() + " który napisał '" + message + "'.");
        }
    }
}